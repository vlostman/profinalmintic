export const OcultarMenu = () => {
    document.body.classList.toggle("toggle-sidebar");
};
