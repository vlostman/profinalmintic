import { Link } from "react-router-dom";

import "./../../../assets/css/portada.css";
import "./../../../assets/css/carousel.css";


import logoReact from "./../../../assets/image/logoReact.png";
import avat1 from "./../../../assets/image/kelly.jpg";
import avat2 from "./../../../assets/image/Jeffrey.jpg";

export const Principal = () => {
  return (
    <div>
      {/* Barra de navegación: Inicio */}
      <header>
        <nav className="navbar navbar-expand-md fixed-top bg-light">
          <div className="container-fluid">
            <Link to="/" className="navbar-brand, textColor" >
              <img src={logoReact} alt="" /> Tu Doctor Online
            </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarCollapse"
              aria-controls="navbarCollapse"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarCollapse">
              <ul className="navbar-nav me-auto mb-2 mb-md-0">
                <li className="nav-item, tm-link left">
                  <a className="nav-link" aria-current="page" href="/">
                    Inicio
                  </a>
                </li>
                <li className="nav-item, tm-link left">
                  <Link to="/contacto">
                    <a className="nav-link" href="/contacto">
                      Contactanos
                    </a>
                  </Link>
                </li>
                <li className="nav-item, tm-link left">
                  <Link to="/nosotros">
                    <a className="nav-link" href="/nosotros">
                      Nosotros
                    </a>
                  </Link>
                </li>
                <li className="nav-item dropdown, tm-link left">
                  <a
                    className="nav-link dropdown-toggle"
                    href="/#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Servicios
                  </a>
                  <ul className="dropdown-menu">
                    <li>

                      <a className="dropdown-item" href="/#">
                        <Link to="/medicinageneral">
                          Medicina General
                        </Link>
                      </a>
                    </li>

                    <li>

                      <a className="dropdown-item" href="/#">
                        <Link to="/medicinainterna">
                          Medicina Interna
                        </Link>
                      </a>
                    </li>

                    <li>

                      <a className="dropdown-item" href="/#">
                        <Link to="/medicinaestetica">
                          Medicina estetica
                        </Link>
                      </a>
                    </li>

                    <li>

                      <a className="dropdown-item" href="/#">
                        <Link to="/odontologia">
                          Odontologia
                        </Link>
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
              <Link to="/login">
                <span className="navbar-text">Iniciar Sesion</span>
              </Link>
            </div>
          </div>
        </nav>
      </header>
      {/* Barra de navegación: Fin */}

      <main>
        {/* Cuerpo página principal: Inicio */}
        {/* *************************************************************** */}

        <div id="parallax-world-of-ugg">

          <section>
            <div className="title">
              <h3>Bienvenido a</h3>
              <h1>Tu Doctor Online</h1>
            </div>
          </section>

          <section>
            <div className="parallax-one">
              <h2>Lo que ofrecemos</h2>
            </div>
          </section>

          <section>
            <div className="block">
              <p><span className="first-character sc">C</span>ada vez es más importante para las empresas que tienen presencia online, contar con un sitio web que genere valor y cree percepciones positivas. Para ello, el diseño y desarrollo de una web debe ser hecho a medida, de forma que se ajuste a las necesidades del cliente y no a las de una plataforma de código abierto.
Para esto y de forma personalizada se crea primero la importancia de un diseño web atractivo y convincente haciendo uso de tecnicas como el minimalisto y los colores suaves..</p>
              <p className="line-break margin-top-10"></p>
              <p className="margin-top-10">Por eso es importante contar con un diseño interesante, ademas de implementar funcionalidades dentro de la app que sea fresco y novedoso o no usual dentro del desarrollos de la misma indoles de cara a generar un recuerdo agradable en el usuario.
Esto aplica tambien a los motores de busqueda y la optimizacion de la app misma, los tiempos de carga que soporten la funcionalidad del sistema como la posiblidad de que el proyecto tenga la oportunidad de ser escalable de tal forma que pueda suplir las necesidades del usuario en mayor medida como la gestion y administracion del gestor de contenidos.  </p>
            </div>
          </section>

          <section>
            <div className="parallax-two">
              <h2>Grupo de Desarrollo</h2>
            </div>
          </section>

          <section>
            <div className="block">
              <p><span className="first-character ny">S</span>omos un grupo de emprendedores del area de programacion,
                fielmente comprometidos con la visión de un mismo emprendimiento aplicando principios
                y competencias como por ejemplo: liderazgo, innovación, adaptación, etc.
                Con estas ganas de adquirir capacidades y estar expuestos a constantes retos
                que beneficien nuestro crecimiento intelectual que como fijado principal tengamos
                las siguientes metas a desarrollo.</p>
              <p className="line-break margin-top-10"></p>
              <p className="margin-top-10">TuDoctorOnline es una plataforma para el agendamiento de servicios médicos, permite a los usuarios
registrarse de manera gratuita y acceder al sistema de solicitud de citas médicas.</p>
              <p className="line-break margin-top-10"></p>
              <p className="margin-top-10">Estamos conformados por:</p>
            
            {/* Carousel */}
            {/* *************************************************************** */}
            <figure className="snip1543">
  <img src="https://avatars.githubusercontent.com/u/36352567?v=4" alt="sample108" />
  <figcaption>
    <p>David Munive</p>    <p>Developer/Designer</p>
  </figcaption>

</figure>
<figure className="snip1543"><img src={avat2} alt="sample101" />
  <figcaption>
  <p>Jeffrey Jimenez</p>    <p>Developer</p>
  </figcaption>

</figure>
<figure className="snip1543"><img src={avat1} alt="sample101" />
  <figcaption>
  <p>Kelly Ibarra Flechas</p>    <p>Developer</p>
  </figcaption>

</figure>
<figure className="snip1543"><img src="https://lanpixel.com/wp-content/uploads/2021/05/computacion-en-la-nube-460x460.png" alt="sample101" />
  <figcaption>
  <p>Jaime Mantilla</p>    <p>Developer</p>
  </figcaption>

</figure>
<figure className="snip1543"><img src="https://lanpixel.com/wp-content/uploads/2021/05/computacion-en-la-nube-460x460.png" alt="sample101" />
  <figcaption>
  <p>Jesus Gutierrez</p>    <p>Developer</p>
  </figcaption>

</figure>



            {/* *************************************************************** */}
            {/* Carousel */}
            </div>
          </section>

          <section>
            <div className="parallax-three">
              <h2>Acerca del Programa</h2>
            </div>
          </section>

          <section>
            <div className="block">
              <p><span className="first-character atw">E</span>l Grupo Mintic y sus Programas de educacion junto a la Universidad Industrial de Santander UIS son una iniciativa para ayudar a los futuros programadores. Se enfoca en proporcionar educacion y crear personas más eficientes, ya que el código requiere ser entendido de forma simple. Ayudaremos a los programadores a desarrollar conceptos en diferentes lenguajes de programación.</p>
              <p className="line-break margin-top-10"></p>
              <p className="margin-top-10">Estos incluyen Java, HTML, CSS, Bootstrap, JavaScript, Android, SQL y Algorithm.</p>
            </div>
          </section>

        </div>
        {/* *************************************************************** */}
        {/* Cuerpo página principal: Fin */}




        {/* Footer: Inicio */}
        {/* *************************************************************** */}

        <footer className="footer">
          <div className="container">
            <ul className="list-inline mb-0 text-center">
              <li>
                <Link to="/nosotros">
                  Copyright 2022 All Rights Reserved by Desarrollo de Software Mintic/UIS - U16/Grupo 10 - Tu Doctor Online
                </Link>
              </li>
              <li className="list-inline-item">
                <a href="/#"><span className="fab fa-twitter"></span></a>
              </li>

              <li className="list-inline-item">
                <a href="/#"><span className="fab fa-dribbble"></span></a>
              </li>

              <li className="list-inline-item">
                <a href="/#"><span className="fab fa-facebook-f"></span></a>
              </li>

              <li className="list-inline-item">
                <a href="/#"><span className="fab fa-linkedin-in"></span></a>
              </li>
            </ul>
          </div>
        </footer>
        {/* *************************************************************** */}
        {/* Footer: Fin */}
      </main>
    </div>
  );
};

